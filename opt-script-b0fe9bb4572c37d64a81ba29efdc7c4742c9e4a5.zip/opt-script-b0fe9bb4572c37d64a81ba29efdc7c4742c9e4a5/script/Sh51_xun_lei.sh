#!/bin/bash
#copyright by hiboy
# 失效清理
echo "Sh51_xun_lei"
